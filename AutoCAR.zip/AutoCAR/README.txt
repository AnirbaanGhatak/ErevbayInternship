Install all python dependencies


to run flask - python -m flask run      
