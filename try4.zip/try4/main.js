function newpage(){
    var pass = getElementById("pass");
    var user = getElementById("user");
    if(pass=="1234"&&user=="abc"){
        
    }
}