import webbrowser
import pyautogui
import pytesseract
import cv2
import numpy as np
import os
from time import sleep
import pandas as pd
import datetime


def check_internet():
    cmd = os.system('ping google.com -w 4 > clear')
    if cmd == 0:
        return True
    else:
        return False


def check_number(number):
    number=str(number)
    number=number[:-2]
    if(number==np.nan):
        return ""
    webbrowser.open("https://api.whatsapp.com/send/?phone={}&text&type=phone_number&app_absent=0".format(number))
    # sleep(2)
    # pyautogui.click(898, 480)
    sleep(4)
    if(pyautogui.locateOnScreen('notvalidwindows.jpg',confidence=0.5)):
        print(f"{number},Invalid")
        return "Invalid"
    else:
        print(f"{number},Valid")
        return "Valid"



if __name__=='__main__':
    # get the current time
    print(datetime.datetime.now().time())
    try:
        allData = pd.DataFrame()
        folder_loc=input("File location:")
        # with open(folder_loc,"r") as file:    
        data=pd.read_excel(folder_loc)
        data=data[:100]
        # allData=data.copy()
        # raise Exception("Hello")
        # data['Valid-Exp']=data['Mobile'].apply(check_number)
        os.system("taskkill /im chrome.exe /f")
        chunks = np.array_split(data, 9)
        for chunk in chunks:
            if(check_internet()):
                print(chunk.shape)
                os.system("taskkill /im chrome.exe /f")
                # os.system("killall -9 'Safari'")
                chunk['valid']=chunk['Mobile'].apply(check_number)
                allData = allData.append(chunk)
            else:
                raise Exception("No net")
        allData.to_csv(f'{os.getcwd()}/outputs/output.csv')
    except Exception as e:
        print(e)
        allData.to_csv(f'{os.getcwd()}/outputs/output.csv')
    print(datetime.datetime.now().time())